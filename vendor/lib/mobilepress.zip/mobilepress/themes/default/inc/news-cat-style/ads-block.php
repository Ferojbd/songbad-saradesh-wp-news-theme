<div class="homeTop">
    <div style="margin-bottom:_10px">
        <?php echo $specific_cat_group_value['news-cat-ads-banner'];?>
    </div>
    <div class="spacebar"></div>
</div>
